import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // News Articles Routes
  app.get("/api/news", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const category = req.query.category as string;
      const articles = await storage.getNewsArticles(limit, category);
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch news articles" });
    }
  });

  app.get("/api/news/:limit", async (req, res) => {
    try {
      const limit = parseInt(req.params.limit as string) || 10;
      const articles = await storage.getNewsArticles(limit);
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch news articles" });
    }
  });

  app.get("/api/news/breaking", async (req, res) => {
    try {
      const articles = await storage.getBreakingNews();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch breaking news" });
    }
  });

  app.get("/api/news/hot", async (req, res) => {
    try {
      const articles = await storage.getHotNews();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch hot news" });
    }
  });

  app.get("/api/news/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const article = await storage.getNewsArticle(id);
      if (!article) {
        return res.status(404).json({ error: "Article not found" });
      }
      
      // Update view count
      await storage.updateNewsViews(id);
      
      res.json(article);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch article" });
    }
  });

  // Categories Routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const category = await storage.getCategory(slug);
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch category" });
    }
  });

  // Trending Topics Routes
  app.get("/api/trending", async (req, res) => {
    try {
      const topics = await storage.getTrendingTopics();
      res.json(topics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trending topics" });
    }
  });

  // Search Routes
  app.get("/api/search", async (req, res) => {
    try {
      const searchSchema = z.object({
        q: z.string().min(1),
        language: z.enum(["hi", "en"]).optional().default("hi"),
      });

      const { q, language } = searchSchema.parse(req.query);
      const results = await storage.searchNews(q, language);
      res.json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid search parameters" });
      }
      res.status(500).json({ error: "Search failed" });
    }
  });

  // File downloader route
  app.get("/download", (req, res) => {
    res.sendFile(path.join(process.cwd(), "file-downloader.html"));
  });

  const httpServer = createServer(app);
  return httpServer;
}
