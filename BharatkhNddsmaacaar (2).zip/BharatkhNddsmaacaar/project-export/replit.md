# Replit.md - भारतखण्ड समाचार (Hindi News Portal)

## Overview

This is a full-stack Hindi news portal web application built with React/TypeScript frontend and Express.js backend. The application serves as a modern news website featuring bilingual content (Hindi/English), categorized news articles, breaking news alerts, trending topics, and a responsive design optimized for both desktop and mobile devices.

The application follows a news media architecture with content management capabilities, search functionality, and social media integration. It's designed to handle high-traffic scenarios typical of news websites while maintaining fast loading times and excellent user experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing without heavy dependencies
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Shadcn/ui components with Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom brand colors and Hindi/English font support
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework for RESTful API development
- **Database ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Database**: Configured for PostgreSQL with Neon Database serverless driver
- **Data Storage**: Currently uses in-memory storage for development with database schema ready for production
- **API Design**: RESTful endpoints following standard HTTP conventions

### Database Schema
- **News Articles**: Main content table with bilingual support (Hindi/English)
- **Categories**: News categorization with localized names and URL-friendly slugs
- **Trending Topics**: Real-time trending hashtags with ranking system
- **Fields**: Comprehensive article metadata including view counts, breaking news flags, publish dates

### Authentication & Authorization
- Currently implements a basic session-based approach
- No complex user authentication system implemented (suitable for public news consumption)
- Admin functionality would need to be added for content management

### Internationalization (i18n)
- **Language Support**: Built-in Hindi/English bilingual system
- **Font Strategy**: Noto Sans Devanagari for Hindi, Inter for English
- **Content Strategy**: Dual content fields in database for both languages
- **User Preference**: Language toggle with localStorage persistence

### Performance Optimizations
- **Caching**: TanStack Query provides intelligent caching and background updates
- **Code Splitting**: Vite handles automatic code splitting for optimal loading
- **Image Optimization**: External image URLs with placeholder support
- **Mobile Responsiveness**: Tailwind breakpoints for optimal mobile experience

### Content Management
- **Categories**: Politics, Crime, National, Entertainment, Opinion, Special, Sports, Business, Education
- **Content Types**: Regular articles, breaking news, hot news with priority flags
- **Media Support**: Image integration with external URL support
- **SEO**: Structured content with excerpts and metadata

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon Database
- **drizzle-orm**: Modern TypeScript ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React router
- **express**: Node.js web framework for backend API

### UI & Styling
- **@radix-ui/**: Complete set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **clsx**: Conditional CSS class composition

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Type safety and enhanced developer experience
- **drizzle-kit**: Database migration and schema management tools

### Font & Icons
- **Google Fonts**: Noto Sans Devanagari (Hindi), Inter (English)
- **Font Awesome**: Social media and UI icons (referenced via CDN)

### Database
- **PostgreSQL**: Primary database (configured but can use any PostgreSQL provider)
- **Neon Database**: Serverless PostgreSQL hosting (development ready)

### Optional Services
- **YouTube Integration**: Subscription widget for news channel promotion
- **Social Media**: Facebook, Twitter, Instagram integration placeholders
- **Search**: Basic text search functionality across news articles

### Development Dependencies
- **@replit/**: Replit-specific development tools and error handling
- **postcss**: CSS processing for Tailwind
- **autoprefixer**: CSS vendor prefix automation