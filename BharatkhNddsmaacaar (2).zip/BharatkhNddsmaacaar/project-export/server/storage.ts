import { type NewsArticle, type InsertNewsArticle, type Category, type TrendingTopic } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // News Articles
  getNewsArticles(limit?: number, category?: string): Promise<NewsArticle[]>;
  getNewsArticle(id: string): Promise<NewsArticle | undefined>;
  getBreakingNews(): Promise<NewsArticle[]>;
  getHotNews(): Promise<NewsArticle[]>;
  createNewsArticle(article: InsertNewsArticle): Promise<NewsArticle>;
  updateNewsViews(id: string): Promise<void>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(slug: string): Promise<Category | undefined>;
  
  // Trending Topics
  getTrendingTopics(): Promise<TrendingTopic[]>;
  
  // Search
  searchNews(query: string, language?: string): Promise<NewsArticle[]>;
}

export class MemStorage implements IStorage {
  private newsArticles: Map<string, NewsArticle>;
  private categories: Map<string, Category>;
  private trendingTopics: Map<string, TrendingTopic>;

  constructor() {
    this.newsArticles = new Map();
    this.categories = new Map();
    this.trendingTopics = new Map();
    this.initializeData();
  }

  private initializeData() {
    // Initialize categories
    const categoriesData: Category[] = [
      { id: "1", name: "मुख्य पृष्ठ", nameEn: "Home", slug: "home" },
      { id: "2", name: "राजनीति", nameEn: "Politics", slug: "politics" },
      { id: "3", name: "अपराध", nameEn: "Crime", slug: "crime" },
      { id: "4", name: "देश", nameEn: "National", slug: "national" },
      { id: "5", name: "मनोरंजन", nameEn: "Entertainment", slug: "entertainment" },
      { id: "6", name: "विचार", nameEn: "Opinion", slug: "opinion" },
      { id: "7", name: "विशेष", nameEn: "Special", slug: "special" },
      { id: "8", name: "खेल", nameEn: "Sports", slug: "sports" },
      { id: "9", name: "व्यापार", nameEn: "Business", slug: "business" },
      { id: "10", name: "शिक्षा", nameEn: "Education", slug: "education" },
    ];

    categoriesData.forEach(category => {
      this.categories.set(category.id, category);
    });

    // Initialize trending topics
    const trendingData: TrendingTopic[] = [
      { id: "1", hashtag: "#नई_शिक्षा_नीति", hashtagEn: "#NewEducationPolicy", rank: 1, count: 1500 },
      { id: "2", hashtag: "#विधानसभा_चुनाव", hashtagEn: "#AssemblyElection", rank: 2, count: 1200 },
      { id: "3", hashtag: "#औद्योगिक_विकास", hashtagEn: "#IndustrialDevelopment", rank: 3, count: 980 },
      { id: "4", hashtag: "#फिल्म_समीक्षा", hashtagEn: "#MovieReview", rank: 4, count: 850 },
      { id: "5", hashtag: "#क्रिकेट_विश्वकप", hashtagEn: "#CricketWorldCup", rank: 5, count: 720 },
    ];

    trendingData.forEach(topic => {
      this.trendingTopics.set(topic.id, topic);
    });

    // Initialize sample news articles
    const newsData: NewsArticle[] = [
      {
        id: randomUUID(),
        title: "प्रधानमंत्री मोदी ने राष्ट्रीय शिक्षा नीति के तहत नए सुधारों की घोषणा की",
        titleEn: "PM Modi announces new reforms under National Education Policy",
        content: "नई दिल्ली में आयोजित एक कार्यक्रम में प्रधानमंत्री नरेंद्र मोदी ने शिक्षा व्यवस्था में व्यापक सुधार की घोषणा की है। इस नई नीति से देश के लाखों छात्रों को फायदा होगा।",
        contentEn: "Prime Minister Narendra Modi announced comprehensive education system reforms at an event in New Delhi. This new policy will benefit millions of students across the country.",
        excerpt: "नई दिल्ली में आयोजित एक कार्यक्रम में प्रधानमंत्री नरेंद्र मोदी ने शिक्षा व्यवस्था में व्यापक सुधार की घोषणा की है।",
        excerptEn: "Prime Minister Narendra Modi announced comprehensive education system reforms at an event in New Delhi.",
        category: "राजनीति",
        categoryEn: "Politics",
        imageUrl: "https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 1,
        isHot: 1,
        views: 2500,
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "उत्तर प्रदेश में बड़ा औद्योगिक निवेश, हजारों नौकरियों के अवसर",
        titleEn: "Major industrial investment in Uttar Pradesh, thousands of job opportunities",
        content: "उत्तर प्रदेश सरकार ने एक बड़ी औद्योगिक परियोजना को मंजूरी दी है जो राज्य में हजारों नए रोजगार के अवसर पैदा करेगी।",
        contentEn: "The Uttar Pradesh government has approved a major industrial project that will create thousands of new employment opportunities in the state.",
        excerpt: "उत्तर प्रदेश सरकार ने एक बड़ी औद्योगिक परियोजना को मंजूरी दी है।",
        excerptEn: "The Uttar Pradesh government has approved a major industrial project.",
        category: "व्यापार",
        categoryEn: "Business",
        imageUrl: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 1,
        views: 1800,
        publishedAt: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
        createdAt: new Date(Date.now() - 45 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "बॉलीवुड की नई फिल्म ने बॉक्स ऑफिस पर मचाई धूम",
        titleEn: "New Bollywood film creates buzz at box office",
        content: "इस सप्ताह रिलीज़ हुई नई बॉलीवुड फिल्म ने बॉक्स ऑफिस पर शानदार प्रदर्शन किया है।",
        contentEn: "The new Bollywood film released this week has performed brilliantly at the box office.",
        excerpt: "इस सप्ताह रिलीज़ हुई नई बॉलीवुड फिल्म ने बॉक्स ऑफिस पर शानदार प्रदर्शन किया है।",
        excerptEn: "The new Bollywood film released this week has performed brilliantly at the box office.",
        category: "मनोरंजन",
        categoryEn: "Entertainment",
        imageUrl: "https://images.unsplash.com/photo-1489599556821-eca5bb832b23?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 1200,
        publishedAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
        createdAt: new Date(Date.now() - 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "किसानों के लिए नई सब्सिडी योजना की शुरुआत",
        titleEn: "New subsidy scheme launched for farmers",
        content: "केंद्र सरकार ने किसानों के लिए एक नई सब्सिडी योजना की घोषणा की है।",
        contentEn: "The central government has announced a new subsidy scheme for farmers.",
        excerpt: "केंद्र सरकार ने किसानों के लिए एक नई सब्सिडी योजना की घोषणा की है।",
        excerptEn: "The central government has announced a new subsidy scheme for farmers.",
        category: "देश",
        categoryEn: "National",
        imageUrl: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 980,
        publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "विधानसभा चुनाव की तैयारियों में जुटी सरकार",
        titleEn: "Government busy preparing for assembly elections",
        content: "राज्य सरकार ने आगामी विधानसभा चुनाव की तैयारियों को लेकर अहम बैठक की है।",
        contentEn: "The state government has held an important meeting regarding preparations for the upcoming assembly elections.",
        excerpt: "राज्य सरकार ने आगामी विधानसभा चुनाव की तैयारियों को लेकर अहम बैठक की है।",
        excerptEn: "The state government has held an important meeting regarding preparations for the upcoming assembly elections.",
        category: "राजनीति",
        categoryEn: "Politics",
        imageUrl: "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 1500,
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "जालसाजी के मामले में दो गिरफ्तार",
        titleEn: "Two arrested in fraud case",
        content: "पुलिस ने बैंक फ्रॉड के मामले में दो संदिग्धों को गिरफ्तार किया है।",
        contentEn: "Police have arrested two suspects in a bank fraud case.",
        excerpt: "पुलिस ने बैंक फ्रॉड के मामले में दो संदिग्धों को गिरफ्तार किया है।",
        excerptEn: "Police have arrested two suspects in a bank fraud case.",
        category: "अपराध",
        categoryEn: "Crime",
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 856,
        publishedAt: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "टी-20 विश्व कप में भारत की शानदार जीत",
        titleEn: "India's spectacular victory in T-20 World Cup",
        content: "टी-20 विश्व कप के फाइनल में भारत ने शानदार प्रदर्शन करते हुए ऑस्ट्रेलिया को हराया है।",
        contentEn: "India defeated Australia with a spectacular performance in the T-20 World Cup final.",
        excerpt: "टी-20 विश्व कप के फाइनल में भारत ने शानदार प्रदर्शन करते हुए ऑस्ट्रेलिया को हराया है।",
        excerptEn: "India defeated Australia with a spectacular performance in the T-20 World Cup final.",
        category: "खेल",
        categoryEn: "Sports",
        imageUrl: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 1,
        isHot: 1,
        views: 3200,
        publishedAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
        createdAt: new Date(Date.now() - 30 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "स्वच्छ भारत मिशन के तहत गांवों में नए शौचालयों का निर्माण",
        titleEn: "Construction of new toilets in villages under Swachh Bharat Mission",
        content: "स्वच्छ भारत मिशन के तहत ग्रामीण इलाकों में हजारों नए शौचालयों का निर्माण किया जा रहा है।",
        contentEn: "Thousands of new toilets are being constructed in rural areas under the Swachh Bharat Mission.",
        excerpt: "स्वच्छ भारत मिशन के तहत ग्रामीण इलाकों में हजारों नए शौचालयों का निर्माण किया जा रहा है।",
        excerptEn: "Thousands of new toilets are being constructed in rural areas under the Swachh Bharat Mission.",
        category: "विशेष",
        categoryEn: "Special",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 892,
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "आयुष्मान भारत योजना में नए सुधार",
        titleEn: "New reforms in Ayushman Bharat scheme",
        content: "केंद्र सरकार ने आयुष्मान भारत योजना में महत्वपूर्ण सुधार की घोषणा की है।",
        contentEn: "The central government has announced important reforms in the Ayushman Bharat scheme.",
        excerpt: "केंद्र सरकार ने आयुष्मान भारत योजना में महत्वपूर्ण सुधार की घोषणा की है।",
        excerptEn: "The central government has announced important reforms in the Ayushman Bharat scheme.",
        category: "देश",
        categoryEn: "National",
        imageUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 1,
        views: 1456,
        publishedAt: new Date(Date.now() - 90 * 60 * 1000), // 90 minutes ago
        createdAt: new Date(Date.now() - 90 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "कपिल शर्मा के शो में नए कलाकारों का एंट्री",
        titleEn: "New artists enter Kapil Sharma's show",
        content: "कॉमेडी किंग कपिल शर्मा के शो में कुछ नए कलाकारों का एंट्री हुआ है।",
        contentEn: "Some new artists have entered comedy king Kapil Sharma's show.",
        excerpt: "कॉमेडी किंग कपिल शर्मा के शो में कुछ नए कलाकारों का एंट्री हुआ है।",
        excerptEn: "Some new artists have entered comedy king Kapil Sharma's show.",
        category: "मनोरंजन",
        categoryEn: "Entertainment",
        imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 1120,
        publishedAt: new Date(Date.now() - 7 * 60 * 60 * 1000), // 7 hours ago
        createdAt: new Date(Date.now() - 7 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "साइबर अपराध में तेजी से वृद्धि, पुलिस ने जारी की चेतावनी",
        titleEn: "Rapid increase in cybercrime, police issued warning",
        content: "देश में साइबर अपराध के मामलों में तेजी से वृद्धि हो रही है। पुलिस ने लोगों को सावधान रहने की चेतावनी दी है।",
        contentEn: "Cybercrime cases are increasing rapidly in the country. Police have warned people to be careful.",
        excerpt: "देश में साइबर अपराध के मामलों में तेजी से वृद्धि हो रही है।",
        excerptEn: "Cybercrime cases are increasing rapidly in the country.",
        category: "अपराध",
        categoryEn: "Crime",
        imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 1,
        views: 1680,
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "शेयर बाजार में भारी गिरावट, निवेशकों में चिंता",
        titleEn: "Heavy fall in stock market, concern among investors",
        content: "आज शेयर बाजार में भारी गिरावट देखी गई है। निवेशकों में चिंता का माहौल है।",
        contentEn: "Heavy fall was seen in the stock market today. There is an atmosphere of concern among investors.",
        excerpt: "आज शेयर बाजार में भारी गिरावट देखी गई है।",
        excerptEn: "Heavy fall was seen in the stock market today.",
        category: "व्यापार",
        categoryEn: "Business",
        imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 1,
        isHot: 0,
        views: 2100,
        publishedAt: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
        createdAt: new Date(Date.now() - 15 * 60 * 1000),
      },
      {
        id: randomUUID(),
        title: "ऑनलाइन शिक्षा प्लेटफॉर्म में नई तकनीक का इस्तेमाल",
        titleEn: "Use of new technology in online education platform",
        content: "ऑनलाइन शिक्षा प्लेटफॉर्म्स में AI और मशीन लर्निंग का इस्तेमाल बढ़ रहा है।",
        contentEn: "The use of AI and machine learning is increasing in online education platforms.",
        excerpt: "ऑनलाइन शिक्षा प्लेटफॉर्म्स में AI और मशीन लर्निंग का इस्तेमाल बढ़ रहा है।",
        excerptEn: "The use of AI and machine learning is increasing in online education platforms.",
        category: "शिक्षा",
        categoryEn: "Education",
        imageUrl: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        isBreaking: 0,
        isHot: 0,
        views: 745,
        publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000), // 8 hours ago
        createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
      }
    ];

    newsData.forEach(article => {
      this.newsArticles.set(article.id, article);
    });
  }

  async getNewsArticles(limit = 10, category?: string): Promise<NewsArticle[]> {
    let articles = Array.from(this.newsArticles.values());
    
    if (category && category !== "home") {
      const categoryData = Array.from(this.categories.values()).find(
        c => c.slug === category || c.name === category
      );
      if (categoryData) {
        articles = articles.filter(article => 
          article.category === categoryData.name || article.categoryEn === categoryData.nameEn
        );
      }
    }
    
    return articles
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
      .slice(0, limit);
  }

  async getNewsArticle(id: string): Promise<NewsArticle | undefined> {
    return this.newsArticles.get(id);
  }

  async getBreakingNews(): Promise<NewsArticle[]> {
    return Array.from(this.newsArticles.values())
      .filter(article => article.isBreaking === 1)
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
  }

  async getHotNews(): Promise<NewsArticle[]> {
    return Array.from(this.newsArticles.values())
      .filter(article => article.isHot === 1)
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
  }

  async createNewsArticle(insertArticle: InsertNewsArticle): Promise<NewsArticle> {
    const id = randomUUID();
    const article: NewsArticle = {
      ...insertArticle,
      id,
      views: 0,
      publishedAt: new Date(),
      createdAt: new Date(),
    };
    this.newsArticles.set(id, article);
    return article;
  }

  async updateNewsViews(id: string): Promise<void> {
    const article = this.newsArticles.get(id);
    if (article) {
      article.views += 1;
      this.newsArticles.set(id, article);
    }
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(c => c.slug === slug);
  }

  async getTrendingTopics(): Promise<TrendingTopic[]> {
    return Array.from(this.trendingTopics.values()).sort((a, b) => a.rank - b.rank);
  }

  async searchNews(query: string, language = "hi"): Promise<NewsArticle[]> {
    const articles = Array.from(this.newsArticles.values());
    const searchTerm = query.toLowerCase();
    
    return articles.filter(article => {
      if (language === "en") {
        return (
          (article.titleEn?.toLowerCase().includes(searchTerm)) ||
          (article.contentEn?.toLowerCase().includes(searchTerm)) ||
          (article.excerptEn?.toLowerCase().includes(searchTerm))
        );
      } else {
        return (
          article.title.toLowerCase().includes(searchTerm) ||
          article.content.toLowerCase().includes(searchTerm) ||
          article.excerpt.toLowerCase().includes(searchTerm)
        );
      }
    }).sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
  }
}

export const storage = new MemStorage();
