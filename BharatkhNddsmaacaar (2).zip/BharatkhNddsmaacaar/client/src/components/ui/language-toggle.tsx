import { useLanguage } from '@/hooks/use-language';

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center bg-white rounded-full p-1 border">
      <button
        onClick={() => setLanguage('hi')}
        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
          language === 'hi'
            ? 'bg-brand-red text-white'
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        हिंदी
      </button>
      <button
        onClick={() => setLanguage('en')}
        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
          language === 'en'
            ? 'bg-brand-red text-white'
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        English
      </button>
    </div>
  );
}
