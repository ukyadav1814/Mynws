import { useLanguage } from '@/hooks/use-language';

interface TickerProps {
  items: string[];
}

export function Ticker({ items }: TickerProps) {
  const { t } = useLanguage();

  return (
    <div className="bg-brand-red text-white py-2 overflow-hidden">
      <div className="container mx-auto px-4 flex items-center">
        <span className="bg-black text-white px-3 py-1 rounded font-bold text-sm mr-4">
          {t('breakingNews')}
        </span>
        <div className="flex-1 overflow-hidden">
          <div className="breaking-news-ticker whitespace-nowrap">
            {items.join(' • ')}
          </div>
        </div>
      </div>
    </div>
  );
}
