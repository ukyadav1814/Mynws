import { Link } from 'wouter';
import { useLanguage } from '@/hooks/use-language';
import { NewsArticle } from '@/types/news';

interface NewsCardProps {
  article: NewsArticle;
  size?: 'default' | 'large';
}

export function NewsCard({ article, size = 'default' }: NewsCardProps) {
  const { language, t } = useLanguage();
  
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInHours >= 1) {
      return `${diffInHours} ${t('hoursAgo')}`;
    } else {
      return `${diffInMinutes} ${t('minutesAgo')}`;
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'राजनीति': 'bg-blue-100 text-blue-800',
      'Politics': 'bg-blue-100 text-blue-800',
      'अपराध': 'bg-red-100 text-red-800',
      'Crime': 'bg-red-100 text-red-800',
      'मनोरंजन': 'bg-purple-100 text-purple-800',
      'Entertainment': 'bg-purple-100 text-purple-800',
      'खेल': 'bg-orange-100 text-orange-800',
      'Sports': 'bg-orange-100 text-orange-800',
      'व्यापार': 'bg-green-100 text-green-800',
      'Business': 'bg-green-100 text-green-800',
      'शिक्षा': 'bg-yellow-100 text-yellow-800',
      'Education': 'bg-yellow-100 text-yellow-800',
      'देश': 'bg-indigo-100 text-indigo-800',
      'National': 'bg-indigo-100 text-indigo-800',
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  const title = language === 'en' && article.titleEn ? article.titleEn : article.title;
  const excerpt = language === 'en' && article.excerptEn ? article.excerptEn : article.excerpt;
  const category = language === 'en' && article.categoryEn ? article.categoryEn : article.category;

  if (size === 'large') {
    return (
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {article.imageUrl && (
          <img 
            src={article.imageUrl} 
            alt={title} 
            className="w-full h-64 object-cover"
          />
        )}
        <div className="p-6">
          <span className={`px-3 py-1 rounded text-sm font-bold ${article.isBreaking ? 'bg-brand-red text-white' : getCategoryColor(category)}`}>
            {article.isBreaking ? t('breakingNews') : category}
          </span>
          <h2 className="text-2xl font-bold text-gray-900 mt-3 mb-3 leading-tight">
            {title}
          </h2>
          <p className="text-gray-600 mb-4">
            {excerpt}
          </p>
          <div className="flex items-center text-sm text-gray-500">
            <i className="far fa-clock mr-2"></i>
            <span>{formatTimeAgo(new Date(article.publishedAt))}</span>
            <span className="mx-2">•</span>
            <span>{category}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Link href={`/news/${article.id}`}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden news-card transition-all cursor-pointer">
        {article.imageUrl && (
          <img 
            src={article.imageUrl} 
            alt={title} 
            className="w-full h-48 object-cover"
          />
        )}
        <div className="p-4">
          <span className={`px-2 py-1 rounded text-xs font-medium ${getCategoryColor(category)}`}>
            {category}
          </span>
          <h3 className="font-bold text-gray-900 mt-2 mb-2 leading-tight">
            {title}
          </h3>
          <p className="text-gray-600 text-sm mb-3">
            {excerpt}
          </p>
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>{formatTimeAgo(new Date(article.publishedAt))}</span>
            <span className="flex items-center">
              <i className="far fa-eye mr-1"></i> 
              {article.views.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
