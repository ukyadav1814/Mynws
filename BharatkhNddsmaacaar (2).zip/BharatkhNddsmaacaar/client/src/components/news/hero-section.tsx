import { useQuery } from '@tanstack/react-query';
import { NewsCard } from './news-card';
import { useLanguage } from '@/hooks/use-language';
import { NewsArticle } from '@/types/news';
import { Skeleton } from '@/components/ui/skeleton';

export function HeroSection() {
  const { t } = useLanguage();
  
  const { data: breakingNews, isLoading: isLoadingBreaking } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news/breaking']
  });

  const { data: topNews, isLoading: isLoadingTop } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news', '3']
  });

  if (isLoadingBreaking || isLoadingTop) {
    return (
      <section className="bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <Skeleton className="h-64 w-full" />
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-20 w-full" />
            </div>
            <div className="space-y-4">
              <Skeleton className="h-8 w-1/2" />
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex gap-4">
                  <Skeleton className="h-20 w-20" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  const mainStory = breakingNews?.[0] || topNews?.[0];
  const sideStories = topNews?.slice(0, 3) || [];

  return (
    <section className="bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Main Story */}
          {mainStory && (
            <div>
              <NewsCard article={mainStory} size="large" />
            </div>
          )}

          {/* Top 3 News Stories */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-gray-900 border-l-4 border-brand-red pl-3">
              {t('topNews')}
            </h3>
            
            {sideStories.map((article, index) => (
              <div key={article.id} className="bg-white rounded-lg shadow p-4 hover:shadow-lg transition-all">
                <div className="flex gap-4">
                  {article.imageUrl && (
                    <img 
                      src={article.imageUrl} 
                      alt={article.title} 
                      className="w-20 h-20 object-cover rounded"
                    />
                  )}
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-900 mb-2">
                      {article.title}
                    </h4>
                    <div className="text-sm text-gray-500">
                      <span>
                        {Math.floor((Date.now() - new Date(article.publishedAt).getTime()) / (1000 * 60))} {t('minutesAgo')}
                      </span>
                      <span className="mx-1">•</span>
                      <span>{article.category}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
