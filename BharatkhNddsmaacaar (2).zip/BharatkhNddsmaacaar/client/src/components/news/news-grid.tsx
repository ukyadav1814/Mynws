import { useQuery } from '@tanstack/react-query';
import { NewsCard } from './news-card';
import { useLanguage } from '@/hooks/use-language';
import { NewsArticle } from '@/types/news';
import { Skeleton } from '@/components/ui/skeleton';

interface NewsGridProps {
  category?: string;
  limit?: number;
}

export function NewsGrid({ category, limit = 6 }: NewsGridProps) {
  const { t } = useLanguage();
  
  const { data: news, isLoading, error } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news', limit.toString(), category || '']
  });

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
        {Array.from({ length: limit }).map((_, i) => (
          <div key={i} className="space-y-4">
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">{t('loadingError')}</p>
      </div>
    );
  }

  if (!news || news.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-600">{t('noNewsFound')}</p>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
      {news.map((article) => (
        <NewsCard key={article.id} article={article} />
      ))}
    </div>
  );
}
