import { Link, useLocation } from 'wouter';
import { useLanguage } from '@/hooks/use-language';
import { useState } from 'react';

export function Navigation() {
  const { t } = useLanguage();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { key: 'home', href: '/', label: t('home') },
    { key: 'politics', href: '/politics', label: t('politics') },
    { key: 'crime', href: '/crime', label: t('crime') },
    { key: 'national', href: '/national', label: t('national') },
    { key: 'entertainment', href: '/entertainment', label: t('entertainment') },
    { key: 'opinion', href: '/opinion', label: t('opinion') },
    { key: 'special', href: '/special', label: t('special') },
  ];

  return (
    <nav className="bg-white border-b-2 border-brand-red sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-3">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <h1 className="text-2xl font-bold text-brand-black cursor-pointer">
                भारतखण्ड समाचार
              </h1>
            </Link>
          </div>

          {/* Desktop Navigation Menu */}
          <div className="hidden lg:flex items-center space-x-6">
            {navItems.map((item, index) => {
              if (index === 3) {
                return (
                  <div key="hot-news-group" className="flex items-center space-x-6">
                    <Link href="/hot-news">
                      <button className="bg-brand-red text-white px-6 py-2 rounded-full font-bold hover:bg-brand-black transition-all transform hover:scale-105">
                        🔥 {t('hotNews')}
                      </button>
                    </Link>
                    <Link
                      key={item.key}
                      href={item.href}
                      className={`font-medium border-b-2 border-transparent hover:border-brand-red pb-1 transition-all ${
                        location === item.href ? 'text-brand-red border-brand-red' : 'text-gray-700 hover:text-brand-red'
                      }`}
                    >
                      {item.label}
                    </Link>
                  </div>
                );
              }
              
              return (
                <Link
                  key={item.key}
                  href={item.href}
                  className={`font-medium border-b-2 border-transparent hover:border-brand-red pb-1 transition-all ${
                    location === item.href ? 'text-brand-red border-brand-red' : 'text-gray-700 hover:text-brand-red'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden text-gray-700"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden pb-4 border-t border-gray-200 mt-3">
            <div className="flex flex-col space-y-3 pt-4">
              {navItems.map((item) => (
                <Link
                  key={item.key}
                  href={item.href}
                  className={`font-medium py-2 px-4 rounded transition-all ${
                    location === item.href ? 'text-brand-red bg-red-50' : 'text-gray-700 hover:text-brand-red hover:bg-gray-50'
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <Link href="/hot-news">
                <button 
                  className="bg-brand-red text-white px-6 py-2 rounded-full font-bold hover:bg-brand-black transition-all mx-4"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  🔥 {t('hotNews')}
                </button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
