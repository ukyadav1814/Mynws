import { Link, useLocation } from 'wouter';
import { useLanguage } from '@/hooks/use-language';
import { Home, FileText, Zap, Video, MapPin } from 'lucide-react';

export function BottomNavigation() {
  const { t } = useLanguage();
  const [location] = useLocation();

  const navItems = [
    {
      icon: Home,
      label: t('home'),
      href: '/',
      key: 'home'
    },
    {
      icon: FileText,
      label: 'समाचार',
      href: '/politics',
      key: 'news'
    },
    {
      icon: Zap,
      label: t('hotNews'),
      href: '/hot-news',
      key: 'hot',
      isSpecial: true
    },
    {
      icon: Video,
      label: 'वीडियो',
      href: '/videos',
      key: 'videos'
    },
    {
      icon: MapPin,
      label: 'स्थान',
      href: '/location',
      key: 'location'
    }
  ];

  const isActive = (href: string) => {
    if (href === '/' && location === '/') return true;
    if (href !== '/' && location.startsWith(href)) return true;
    return false;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50 md:hidden">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);
          
          if (item.isSpecial) {
            return (
              <Link key={item.key} href={item.href}>
                <div className="flex flex-col items-center py-1 px-3">
                  <div className="bg-brand-red text-white p-3 rounded-full shadow-lg">
                    <Icon size={20} />
                  </div>
                  <span className="text-xs text-brand-red font-medium mt-1">
                    {item.label}
                  </span>
                </div>
              </Link>
            );
          }

          return (
            <Link key={item.key} href={item.href}>
              <div className={`flex flex-col items-center py-2 px-3 transition-colors ${
                active ? 'text-brand-red' : 'text-gray-600'
              }`}>
                <Icon size={20} />
                <span className="text-xs mt-1 font-medium">
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}