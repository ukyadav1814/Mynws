import { LanguageToggle } from '@/components/ui/language-toggle';

export function Header() {
  const currentDate = new Date().toLocaleDateString('hi-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="bg-gray-100 border-b border-gray-200">
      <div className="container mx-auto px-4 py-2 flex justify-between items-center text-sm">
        <div className="flex items-center space-x-4">
          <span className="text-gray-600">आज का दिन: {currentDate}</span>
        </div>
        <div className="flex items-center space-x-4">
          <LanguageToggle />
          <div className="flex space-x-3">
            <a href="#" className="text-gray-600 hover:text-brand-red transition-colors">
              <i className="fab fa-facebook"></i>
            </a>
            <a href="#" className="text-gray-600 hover:text-brand-red transition-colors">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="text-gray-600 hover:text-brand-red transition-colors">
              <i className="fab fa-youtube"></i>
            </a>
            <a href="#" className="text-gray-600 hover:text-brand-red transition-colors">
              <i className="fab fa-instagram"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
