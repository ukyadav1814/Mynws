import { useLanguage } from '@/hooks/use-language';

export function Footer() {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-brand-black text-white py-8 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-bold mb-4">भारतखण्ड समाचार</h3>
            <p className="text-gray-300 text-sm">
              भारतखण्ड समाचार एक प्रमुख हिंदी न्यूज़ पोर्टल है जो आपको तत्काल और विश्वसनीय समाचार प्रदान करता है।
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold mb-4">महत्वपूर्ण लिंक</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{t('aboutUs')}</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{t('contact')}</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{t('privacyPolicy')}</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{t('termsConditions')}</a></li>
            </ul>
          </div>

          {/* Contact & Social */}
          <div>
            <h4 className="font-bold mb-4">संपर्क</h4>
            <div className="space-y-2 text-sm text-gray-300">
              <p><i className="fas fa-envelope mr-2"></i> contact@bharatkhand.com</p>
              <p><i className="fas fa-phone mr-2"></i> +91 9876543210</p>
            </div>
            <div className="flex space-x-4 mt-4">
              <a href="#" className="text-gray-300 hover:text-white text-lg transition-colors">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white text-lg transition-colors">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white text-lg transition-colors">
                <i className="fab fa-youtube"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white text-lg transition-colors">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            © {currentYear} भारतखण्ड समाचार। {t('allRightsReserved')}
          </p>
        </div>
      </div>
    </footer>
  );
}
