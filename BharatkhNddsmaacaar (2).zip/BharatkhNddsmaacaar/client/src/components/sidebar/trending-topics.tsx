import { useQuery } from '@tanstack/react-query';
import { useLanguage } from '@/hooks/use-language';
import { TrendingTopic } from '@/types/news';
import { Skeleton } from '@/components/ui/skeleton';

export function TrendingTopics() {
  const { t, language } = useLanguage();
  
  const { data: topics, isLoading } = useQuery<TrendingTopic[]>({
    queryKey: ['/api/trending']
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <h3 className="font-bold text-gray-900 mb-4 border-l-4 border-brand-red pl-3">
          {t('trendingTopics')}
        </h3>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center justify-between p-3">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-6 w-6 rounded-full" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!topics || topics.length === 0) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <h3 className="font-bold text-gray-900 mb-4 border-l-4 border-brand-red pl-3">
        {t('trendingTopics')}
      </h3>
      <div className="space-y-3">
        {topics.map((topic) => (
          <div
            key={topic.id}
            className="flex items-center justify-between p-3 hover:bg-gray-50 rounded cursor-pointer transition-colors"
          >
            <span className="text-gray-700">
              {language === 'en' && topic.hashtagEn ? topic.hashtagEn : topic.hashtag}
            </span>
            <span 
              className={`text-white text-xs px-2 py-1 rounded-full ${
                topic.rank === 1 
                  ? 'bg-brand-red' 
                  : 'bg-gray-400'
              }`}
            >
              {topic.rank}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
