import { useLanguage } from '@/hooks/use-language';

export function YouTubeSubscription() {
  const { t } = useLanguage();

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="font-bold text-gray-900 mb-4 border-l-4 border-brand-red pl-3">
        {t('youtubeChannel')}
      </h3>
      <div className="text-center">
        <div className="bg-red-600 rounded-lg p-4 mb-4">
          <i className="fab fa-youtube text-white text-4xl mb-2"></i>
          <p className="text-white font-medium">भारतखण्ड समाचार</p>
        </div>
        <p className="text-gray-600 text-sm mb-4">
          ताज़ा समाचार और विश्लेषण के लिए हमारे यूट्यूब चैनल को सब्सक्राइब करें
        </p>
        <button className="w-full bg-brand-red text-white py-2 px-4 rounded-lg font-bold hover:bg-brand-black transition-all">
          <i className="fab fa-youtube mr-2"></i>
          {t('subscribe')}
        </button>
        <div className="flex justify-around mt-3 text-sm text-gray-600">
          <div className="text-center">
            <div className="font-bold">50K</div>
            <div>{t('subscribers')}</div>
          </div>
          <div className="text-center">
            <div className="font-bold">200+</div>
            <div>{t('videos')}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
