import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLanguage } from '@/hooks/use-language';
import { NewsArticle } from '@/types/news';
import { Link } from 'wouter';

export function SearchBar() {
  const { t, language } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [showResults, setShowResults] = useState(false);

  const { data: searchResults, isLoading } = useQuery<NewsArticle[]>({
    queryKey: ['/api/search', `q=${searchTerm}&language=${language}`],
    enabled: searchTerm.length > 2,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      setShowResults(true);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <h3 className="font-bold text-gray-900 mb-3">{t('searchNews')}</h3>
      <div className="relative">
        <form onSubmit={handleSearch}>
          <input
            type="text"
            placeholder={t('searchPlaceholder')}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onFocus={() => setShowResults(true)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-red focus:border-transparent"
          />
          <button
            type="submit"
            className="absolute right-3 top-3 text-gray-400 hover:text-brand-red transition-colors"
          >
            <i className="fas fa-search"></i>
          </button>
        </form>

        {/* Search Results Dropdown */}
        {showResults && searchTerm.length > 2 && (
          <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-lg shadow-lg mt-1 z-50 max-h-96 overflow-y-auto">
            {isLoading && (
              <div className="p-4 text-center text-gray-500">
                खोज रहे हैं...
              </div>
            )}
            
            {searchResults && searchResults.length > 0 && (
              <div className="py-2">
                {searchResults.slice(0, 5).map((article) => (
                  <Link
                    key={article.id}
                    href={`/news/${article.id}`}
                    onClick={() => setShowResults(false)}
                  >
                    <div className="px-4 py-2 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0">
                      <h4 className="text-sm font-medium text-gray-900 mb-1">
                        {language === 'en' && article.titleEn ? article.titleEn : article.title}
                      </h4>
                      <div className="text-xs text-gray-500">
                        {language === 'en' && article.categoryEn ? article.categoryEn : article.category}
                      </div>
                    </div>
                  </Link>
                ))}
                
                {searchResults.length > 5 && (
                  <div className="px-4 py-2 text-xs text-center text-gray-500 border-t border-gray-100">
                    और {searchResults.length - 5} परिणाम...
                  </div>
                )}
              </div>
            )}
            
            {searchResults && searchResults.length === 0 && (
              <div className="p-4 text-center text-gray-500">
                {t('noNewsFound')}
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Click outside to close */}
      {showResults && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setShowResults(false)}
        />
      )}
    </div>
  );
}
