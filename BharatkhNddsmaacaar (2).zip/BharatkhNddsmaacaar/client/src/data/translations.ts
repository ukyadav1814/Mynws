export const translations = {
  hi: {
    // Navigation
    home: "मुख्य पृष्ठ",
    politics: "राजनीति",
    crime: "अपराध",
    national: "देश",
    entertainment: "मनोरंजन",
    opinion: "विचार",
    special: "विशेष",
    sports: "खेल",
    business: "व्यापार",
    education: "शिक्षा",
    hotNews: "हॉट न्यूज़",
    
    // General
    breakingNews: "ब्रेकिंग न्यूज़",
    latestNews: "ताज़ा समाचार",
    topNews: "टॉप न्यूज़",
    trendingTopics: "ट्रेंडिंग टॉपिक्स",
    searchNews: "समाचार खोजें",
    searchPlaceholder: "यहाँ टाइप करें...",
    readMore: "और पढ़ें",
    viewAll: "सभी समाचार देखें",
    
    // Time
    hoursAgo: "घंटे पहले",
    minutesAgo: "मिनट पहले",
    today: "आज",
    
    // YouTube
    youtubeChannel: "हमारा यूट्यूब चैनल",
    subscribe: "सब्सक्राइब करें",
    subscribers: "सब्सक्राइबर",
    videos: "वीडियो",
    
    // New sections
    videoNews: "वीडियो न्यूज़",
    liveNews: "लाइव न्यूज़",
    location: "स्थान",
    localNews: "स्थानीय समाचार",
    breaking: "ब्रेकिंग",
    live: "लाइव",
    
    // Footer
    aboutUs: "हमारे बारे में",
    contact: "संपर्क करें",
    privacyPolicy: "गोपनीयता नीति",
    termsConditions: "नियम एवं शर्तें",
    allRightsReserved: "सभी अधिकार सुरक्षित।",
    
    // Errors
    noNewsFound: "कोई समाचार नहीं मिला",
    loadingError: "समाचार लोड करने में त्रुटि",
  },
  en: {
    // Navigation
    home: "Home",
    politics: "Politics",
    crime: "Crime",
    national: "National",
    entertainment: "Entertainment",
    opinion: "Opinion",
    special: "Special",
    sports: "Sports",
    business: "Business",
    education: "Education",
    hotNews: "Hot News",
    
    // General
    breakingNews: "Breaking News",
    latestNews: "Latest News",
    topNews: "Top News",
    trendingTopics: "Trending Topics",
    searchNews: "Search News",
    searchPlaceholder: "Type here...",
    readMore: "Read More",
    viewAll: "View All News",
    
    // Time
    hoursAgo: "hours ago",
    minutesAgo: "minutes ago",
    today: "today",
    
    // YouTube
    youtubeChannel: "Our YouTube Channel",
    subscribe: "Subscribe",
    subscribers: "subscribers",
    videos: "videos",
    
    // New sections
    videoNews: "Video News",
    liveNews: "Live News",
    location: "Location",
    localNews: "Local News",
    breaking: "Breaking",
    live: "Live",
    
    // Footer
    aboutUs: "About Us",
    contact: "Contact",
    privacyPolicy: "Privacy Policy",
    termsConditions: "Terms & Conditions",
    allRightsReserved: "All rights reserved.",
    
    // Errors
    noNewsFound: "No news found",
    loadingError: "Error loading news",
  }
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.hi;
