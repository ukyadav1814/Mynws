// This file is for reference only - data is now served from the backend
export const mockNewsData = [
  {
    id: "1",
    title: "प्रधानमंत्री मोदी ने राष्ट्रीय शिक्षा नीति के तहत नए सुधारों की घोषणा की",
    titleEn: "PM Modi announces new reforms under National Education Policy",
    category: "राजनीति",
    categoryEn: "Politics",
    excerpt: "नई दिल्ली में आयोजित एक कार्यक्रम में प्रधानमंत्री नरेंद्र मोदी ने शिक्षा व्यवस्था में व्यापक सुधार की घोषणा की है।",
    imageUrl: "https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    isBreaking: true,
    isHot: true,
    views: 2500,
    publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
  },
  // Add more mock data as needed
];
