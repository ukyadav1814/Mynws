export interface NewsArticle {
  id: string;
  title: string;
  titleEn?: string;
  content: string;
  contentEn?: string;
  excerpt: string;
  excerptEn?: string;
  category: string;
  categoryEn?: string;
  imageUrl?: string;
  isBreaking: number;
  isHot: number;
  views: number;
  publishedAt: Date;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  slug: string;
}

export interface TrendingTopic {
  id: string;
  hashtag: string;
  hashtagEn: string;
  rank: number;
  count: number;
}
