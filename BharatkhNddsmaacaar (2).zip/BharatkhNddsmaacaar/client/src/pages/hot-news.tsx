import { Header } from '@/components/layout/header';
import { Navigation } from '@/components/layout/navigation';
import { Footer } from '@/components/layout/footer';
import { BottomNavigation } from '@/components/layout/bottom-navigation';
import { NewsCard } from '@/components/news/news-card';
import { SearchBar } from '@/components/sidebar/search-bar';
import { TrendingTopics } from '@/components/sidebar/trending-topics';
import { YouTubeSubscription } from '@/components/sidebar/youtube-subscription';
import { useLanguage } from '@/hooks/use-language';
import { useQuery } from '@tanstack/react-query';
import { NewsArticle } from '@/types/news';
import { Skeleton } from '@/components/ui/skeleton';

export default function HotNews() {
  const { t } = useLanguage();
  
  const { data: hotNews, isLoading } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news/hot']
  });

  return (
    <div className="min-h-screen bg-white pb-16 md:pb-0">
      <Header />
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Hot News Content */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900 border-l-4 border-brand-red pl-3">
                🔥 {t('hotNews')}
              </h1>
              <p className="text-gray-600 mt-2">
                आज की सबसे महत्वपूर्ण और ट्रेंडिंग खबरें
              </p>
            </div>

            {isLoading ? (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : hotNews && hotNews.length > 0 ? (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {hotNews.map((article) => (
                  <NewsCard key={article.id} article={article} />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600">{t('noNewsFound')}</p>
              </div>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1">
            <SearchBar />
            <TrendingTopics />
            <YouTubeSubscription />
          </div>
        </div>
      </main>
      
      <Footer />
      <BottomNavigation />
    </div>
  );
}
