import { Header } from '@/components/layout/header';
import { Navigation } from '@/components/layout/navigation';
import { Footer } from '@/components/layout/footer';
import { BottomNavigation } from '@/components/layout/bottom-navigation';
import { NewsCard } from '@/components/news/news-card';
import { SearchBar } from '@/components/sidebar/search-bar';
import { TrendingTopics } from '@/components/sidebar/trending-topics';
import { YouTubeSubscription } from '@/components/sidebar/youtube-subscription';
import { useLanguage } from '@/hooks/use-language';
import { useQuery } from '@tanstack/react-query';
import { NewsArticle } from '@/types/news';
import { Skeleton } from '@/components/ui/skeleton';
import { MapPin, Thermometer, Cloud } from 'lucide-react';

export default function Location() {
  const { t } = useLanguage();
  
  const { data: news, isLoading } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news', '8', '']
  });

  const localAreas = [
    { name: 'नई दिल्ली', temp: '28°C', weather: 'साफ़' },
    { name: 'मुंबई', temp: '32°C', weather: 'बादलछाए' },
    { name: 'कोलकाता', temp: '30°C', weather: 'बारिश' },
    { name: 'चेन्नई', temp: '35°C', weather: 'धूप' },
    { name: 'बेंगलुरु', temp: '25°C', weather: 'साफ़' },
    { name: 'हैदराबाद', temp: '33°C', weather: 'गर्म' }
  ];

  return (
    <div className="min-h-screen bg-white pb-16 md:pb-0">
      <Header />
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Location Content */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900 border-l-4 border-brand-red pl-3">
                📍 {t('localNews')}
              </h1>
              <p className="text-gray-600 mt-2">
                आपके शहर और आस-पास की खबरें
              </p>
            </div>

            {/* Weather Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
              {localAreas.map((area, index) => (
                <div key={index} className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 text-center">
                  <div className="flex items-center justify-center mb-2">
                    <MapPin size={16} className="text-blue-600 mr-1" />
                    <h3 className="font-medium text-gray-900 text-sm">{area.name}</h3>
                  </div>
                  <div className="flex items-center justify-center mb-1">
                    <Thermometer size={14} className="text-red-500 mr-1" />
                    <span className="text-lg font-bold text-gray-800">{area.temp}</span>
                  </div>
                  <div className="flex items-center justify-center">
                    <Cloud size={12} className="text-gray-600 mr-1" />
                    <span className="text-xs text-gray-600">{area.weather}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Location based news */}
            <div className="mb-6">
              <h2 className="text-xl font-bold text-gray-900 border-l-4 border-brand-red pl-3 mb-4">
                स्थानीय समाचार
              </h2>
            </div>

            {isLoading ? (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : news && news.length > 0 ? (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {news.slice(0, 6).map((article) => (
                  <NewsCard key={article.id} article={article} />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600">{t('noNewsFound')}</p>
              </div>
            )}

            {/* City News Sections */}
            <div className="mt-12 grid md:grid-cols-2 gap-8">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                  <MapPin className="text-brand-red mr-2" size={20} />
                  दिल्ली समाचार
                </h3>
                <div className="space-y-3">
                  <div className="border-l-2 border-blue-500 pl-3">
                    <h4 className="font-medium text-gray-900">मेट्रो की नई लाइन का उद्घाटन</h4>
                    <p className="text-sm text-gray-600">दिल्ली मेट्रो की नई लाइन आज से शुरू हो गई है।</p>
                  </div>
                  <div className="border-l-2 border-green-500 pl-3">
                    <h4 className="font-medium text-gray-900">वायु प्रदूषण में कमी</h4>
                    <p className="text-sm text-gray-600">राजधानी में वायु गुणवत्ता में सुधार देखा गया है।</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                  <MapPin className="text-brand-red mr-2" size={20} />
                  मुंबई समाचार
                </h3>
                <div className="space-y-3">
                  <div className="border-l-2 border-purple-500 pl-3">
                    <h4 className="font-medium text-gray-900">स्थानीय ट्रेन सेवा में सुधार</h4>
                    <p className="text-sm text-gray-600">मुंबई लोकल ट्रेन की आवृत्ति बढ़ाई गई है।</p>
                  </div>
                  <div className="border-l-2 border-orange-500 pl-3">
                    <h4 className="font-medium text-gray-900">नए आवास परियोजना की शुरुआत</h4>
                    <p className="text-sm text-gray-600">सरकार ने किफायती आवास योजना शुरू की है।</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1">
            <SearchBar />
            <TrendingTopics />
            <YouTubeSubscription />
          </div>
        </div>
      </main>
      
      <Footer />
      <BottomNavigation />
    </div>
  );
}