import { Header } from '@/components/layout/header';
import { Navigation } from '@/components/layout/navigation';
import { Footer } from '@/components/layout/footer';
import { BottomNavigation } from '@/components/layout/bottom-navigation';
import { HeroSection } from '@/components/news/hero-section';
import { NewsGrid } from '@/components/news/news-grid';
import { SearchBar } from '@/components/sidebar/search-bar';
import { TrendingTopics } from '@/components/sidebar/trending-topics';
import { YouTubeSubscription } from '@/components/sidebar/youtube-subscription';
import { Ticker } from '@/components/ui/ticker';
import { useLanguage } from '@/hooks/use-language';
import { useQuery } from '@tanstack/react-query';
import { NewsArticle } from '@/types/news';

export default function Home() {
  const { t } = useLanguage();
  
  const { data: breakingNews } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news/breaking']
  });

  const breakingNewsTicker = breakingNews?.map(article => article.title) || [
    "प्रधानमंत्री मोदी ने नई शिक्षा नीति पर दिया बड़ा बयान",
    "उत्तर प्रदेश में फिर से लॉकडाउन की संभावना",
    "क्रिकेट विश्व कप में भारत की जीत से खुशी का माहौल"
  ];

  return (
    <div className="min-h-screen bg-white pb-16 md:pb-0">
      <Header />
      <Navigation />
      <Ticker items={breakingNewsTicker} />
      <HeroSection />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* News Grid (3 columns) */}
          <div className="lg:col-span-3">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 border-l-4 border-brand-red pl-3">
                {t('latestNews')}
              </h2>
              <button className="text-brand-red font-medium hover:underline">
                {t('viewAll')}
              </button>
            </div>
            <NewsGrid limit={12} />
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1">
            <SearchBar />
            <TrendingTopics />
            <YouTubeSubscription />
          </div>
        </div>
      </main>
      
      <Footer />
      <BottomNavigation />
    </div>
  );
}
