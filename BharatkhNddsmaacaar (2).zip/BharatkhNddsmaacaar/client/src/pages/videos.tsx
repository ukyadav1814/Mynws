import { Header } from '@/components/layout/header';
import { Navigation } from '@/components/layout/navigation';
import { Footer } from '@/components/layout/footer';
import { BottomNavigation } from '@/components/layout/bottom-navigation';
import { SearchBar } from '@/components/sidebar/search-bar';
import { TrendingTopics } from '@/components/sidebar/trending-topics';
import { YouTubeSubscription } from '@/components/sidebar/youtube-subscription';
import { useLanguage } from '@/hooks/use-language';
import { Play, Clock, Eye } from 'lucide-react';

export default function Videos() {
  const { t } = useLanguage();

  const videoData = [
    {
      id: '1',
      title: 'प्रधानमंत्री मोदी का आज का संबोधन - लाइव',
      thumbnail: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450',
      duration: '45:32',
      views: '2.5 लाख',
      publishedAt: '2 घंटे पहले',
      isLive: true
    },
    {
      id: '2',
      title: 'टी-20 विश्व कप फाइनल हाइलाइट्स',
      thumbnail: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450',
      duration: '15:24',
      views: '5.2 लाख',
      publishedAt: '4 घंटे पहले',
      isLive: false
    },
    {
      id: '3',
      title: 'शेयर बाजार में गिरावट - विशेष चर्चा',
      thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450',
      duration: '22:18',
      views: '1.8 लाख',
      publishedAt: '6 घंटे पहले',
      isLive: false
    },
    {
      id: '4',
      title: 'साइबर अपराध से कैसे बचें - जरूरी टिप्स',
      thumbnail: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450',
      duration: '12:45',
      views: '95 हजार',
      publishedAt: '1 दिन पहले',
      isLive: false
    },
    {
      id: '5',
      title: 'बॉलीवुड की लेटेस्ट फिल्म रिव्यू',
      thumbnail: 'https://images.unsplash.com/photo-1489599556821-eca5bb832b23?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450',
      duration: '18:33',
      views: '3.1 लाख',
      publishedAt: '1 दिन पहले',
      isLive: false
    },
    {
      id: '6',
      title: 'आयुष्मान भारत योजना की पूरी जानकारी',
      thumbnail: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450',
      duration: '25:12',
      views: '1.5 लाख',
      publishedAt: '2 दिन पहले',
      isLive: false
    }
  ];

  return (
    <div className="min-h-screen bg-white pb-16 md:pb-0">
      <Header />
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Video Content */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900 border-l-4 border-brand-red pl-3">
                📺 {t('videoNews')}
              </h1>
              <p className="text-gray-600 mt-2">
                ताज़ा समाचार वीडियो और लाइव कवरेज
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {videoData.map((video) => (
                <div key={video.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all cursor-pointer">
                  <div className="relative">
                    <img 
                      src={video.thumbnail} 
                      alt={video.title} 
                      className="w-full h-48 object-cover"
                    />
                    {video.isLive && (
                      <div className="absolute top-3 left-3 bg-red-600 text-white px-2 py-1 rounded text-xs font-bold">
                        🔴 {t('live')}
                      </div>
                    )}
                    <div className="absolute bottom-3 right-3 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-xs">
                      {video.duration}
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="bg-black bg-opacity-50 rounded-full p-3">
                        <Play className="text-white" size={24} fill="currentColor" />
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-gray-900 mb-2 line-clamp-2">
                      {video.title}
                    </h3>
                    <div className="flex items-center text-sm text-gray-600 space-x-4">
                      <span className="flex items-center">
                        <Eye size={16} className="mr-1" />
                        {video.views}
                      </span>
                      <span className="flex items-center">
                        <Clock size={16} className="mr-1" />
                        {video.publishedAt}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1">
            <SearchBar />
            <TrendingTopics />
            <YouTubeSubscription />
          </div>
        </div>
      </main>
      
      <Footer />
      <BottomNavigation />
    </div>
  );
}