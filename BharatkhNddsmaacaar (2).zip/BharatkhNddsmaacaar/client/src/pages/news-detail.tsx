import { useParams } from 'wouter';
import { Header } from '@/components/layout/header';
import { Navigation } from '@/components/layout/navigation';
import { Footer } from '@/components/layout/footer';
import { BottomNavigation } from '@/components/layout/bottom-navigation';
import { SearchBar } from '@/components/sidebar/search-bar';
import { TrendingTopics } from '@/components/sidebar/trending-topics';
import { YouTubeSubscription } from '@/components/sidebar/youtube-subscription';
import { useLanguage } from '@/hooks/use-language';
import { useQuery } from '@tanstack/react-query';
import { NewsArticle } from '@/types/news';
import { Skeleton } from '@/components/ui/skeleton';
import { Eye, Clock, Share2, BookOpen } from 'lucide-react';

export default function NewsDetail() {
  const { id } = useParams<{ id: string }>();
  const { t, language } = useLanguage();

  const { data: article, isLoading, error } = useQuery<NewsArticle>({
    queryKey: ['/api/news', id]
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white pb-16 md:pb-0">
        <Header />
        <Navigation />
        
        <main className="container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-4 gap-8">
            <div className="lg:col-span-3">
              <Skeleton className="h-8 w-3/4 mb-4" />
              <Skeleton className="h-64 w-full mb-6" />
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </div>
            <div className="lg:col-span-1">
              <SearchBar />
              <TrendingTopics />
              <YouTubeSubscription />
            </div>
          </div>
        </main>
        
        <Footer />
        <BottomNavigation />
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen bg-white pb-16 md:pb-0">
        <Header />
        <Navigation />
        
        <main className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">समाचार नहीं मिला</h1>
            <p className="text-gray-600">यह समाचार उपलब्ध नहीं है या हटा दिया गया है।</p>
          </div>
        </main>
        
        <Footer />
        <BottomNavigation />
      </div>
    );
  }

  const title = language === 'en' && article.titleEn ? article.titleEn : article.title;
  const content = language === 'en' && article.contentEn ? article.contentEn : article.content;
  const category = language === 'en' && article.categoryEn ? article.categoryEn : article.category;

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('hi-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-white pb-16 md:pb-0">
      <Header />
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Article Content */}
          <div className="lg:col-span-3">
            <article className="bg-white">
              {/* Article Header */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <span className="px-3 py-1 bg-brand-red text-white rounded text-sm font-medium">
                    {category}
                  </span>
                  {article.isBreaking === 1 && (
                    <span className="px-3 py-1 bg-red-600 text-white rounded text-sm font-bold">
                      {t('breaking')}
                    </span>
                  )}
                  {article.isHot === 1 && (
                    <span className="px-3 py-1 bg-orange-500 text-white rounded text-sm font-bold">
                      🔥 Hot
                    </span>
                  )}
                </div>
                
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight mb-4">
                  {title}
                </h1>
                
                <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600 mb-6">
                  <div className="flex items-center">
                    <Clock size={16} className="mr-2" />
                    <span>{formatDate(new Date(article.publishedAt))}</span>
                  </div>
                  <div className="flex items-center">
                    <Eye size={16} className="mr-2" />
                    <span>{article.views.toLocaleString()} बार पढ़ा गया</span>
                  </div>
                  <div className="flex items-center">
                    <BookOpen size={16} className="mr-2" />
                    <span>5 मिनट पढ़ने का समय</span>
                  </div>
                </div>

                {/* Share Buttons */}
                <div className="flex items-center gap-3 mb-6">
                  <span className="text-sm font-medium text-gray-700">साझा करें:</span>
                  <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    <i className="fab fa-facebook-f"></i>
                    <span className="text-sm">Facebook</span>
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-blue-400 text-white rounded-lg hover:bg-blue-500 transition-colors">
                    <i className="fab fa-twitter"></i>
                    <span className="text-sm">Twitter</span>
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                    <i className="fab fa-whatsapp"></i>
                    <span className="text-sm">WhatsApp</span>
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                    <Share2 size={16} />
                    <span className="text-sm">अन्य</span>
                  </button>
                </div>
              </div>

              {/* Featured Image */}
              {article.imageUrl && (
                <div className="mb-8">
                  <img 
                    src={article.imageUrl} 
                    alt={title} 
                    className="w-full h-64 md:h-96 object-cover rounded-lg shadow-lg"
                  />
                </div>
              )}

              {/* Article Content */}
              <div className="prose prose-lg max-w-none">
                <div className="text-lg leading-relaxed text-gray-800 space-y-6">
                  {content.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>

              {/* Article Tags */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="flex flex-wrap gap-2">
                  <span className="text-sm font-medium text-gray-700 mr-2">टैग:</span>
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">{category}</span>
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">समाचार</span>
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">भारत</span>
                </div>
              </div>
            </article>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1">
            <SearchBar />
            <TrendingTopics />
            <YouTubeSubscription />
          </div>
        </div>
      </main>
      
      <Footer />
      <BottomNavigation />
    </div>
  );
}