#!/bin/bash

# Create export directory
mkdir -p project-export

# Copy all important project files
echo "Exporting Hindi News Website Project..."

# Copy configuration files
cp package.json project-export/
cp package-lock.json project-export/
cp tsconfig.json project-export/
cp vite.config.ts project-export/
cp tailwind.config.ts project-export/
cp postcss.config.js project-export/
cp components.json project-export/
cp drizzle.config.ts project-export/
cp replit.md project-export/

# Copy source directories
cp -r client project-export/
cp -r server project-export/
cp -r shared project-export/

# Copy assets if they exist
if [ -d "attached_assets" ]; then
    cp -r attached_assets project-export/
fi

echo "Project exported to 'project-export' directory"
echo "You can now compress this folder manually or use:"
echo "tar -czf hindi-news-website.tar.gz project-export/"